<#
.SYNOPSIS
Inveigh is a Windows PowerShell ADIDNS/LLMNR/mDNS/NBNS spoofer/man-in-the-middle tool.

.LINK
https://github.com/Kevin-Robertson/Inveigh
#>
Import-Module $PWD\Inveigh.ps1
Import-Module $PWD\Inveigh-Relay.ps1