# CobaltStrikeCNA
Cobalt Strike Aggressor Scripts

A collection of scripts - from various sources - see script for more info.   
This is just to keep ones I use together. 
Please check the authors for updates and the orginals.

