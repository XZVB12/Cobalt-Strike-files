# AES-PowerShellCode
Standalone version of my AES Powershell payload for Cobalt Strike.

### Usage
* Place a `payload.bin` raw shellcode file in the same directory. Default Architecture is x86
* run `python obfuscate.py`
* Default output is `out.ps1`
