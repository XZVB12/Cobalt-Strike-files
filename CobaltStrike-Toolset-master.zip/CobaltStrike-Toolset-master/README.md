# CobaltStrike-Toolset
Aggressor Script, Kit, Malleable C2 Profiles, External C2 and so on

- ##  Kits

  - #### [ResourceKit](https://github.com/360-A-Team/CobaltStrike-Toolset/tree/master/Kits/ResourceKit)

  - #### [ExploitKit](https://github.com/360-A-Team/CobaltStrike-Toolset/tree/master/Kits/ExploitKit)

- ## Aggressor Script

  - #### [chromedump_mimikatz.cna](https://github.com/360-A-Team/CobaltStrike-Toolset/blob/master/AggressorScript/chromedump_mimikatz.cna)

  - #### [nopowershell](https://github.com/360-A-Team/CobaltStrike-Toolset/blob/master/AggressorScript/nopowershell)

  - #### [SMBexec_psh](https://github.com/360-A-Team/CobaltStrike-Toolset/blob/master/AggressorScript/SMBexec_psh)
  
 
 # Further Resources
 * [nopowershell](https://github.com/bitsadmin/nopowershell)
 * [smbexec_psh.cna](https://gist.github.com/realoriginal/10d8c98845d85b03c552843bf7e1e4db)
 * [CVE-2018-15982](https://github.com/scanfsec/CVE-2018-15982)
 
 # 提示：ResourceKit包中部分功能为自定义功能需要修改cobaltstrike.jar,如需修改版的请联系我，联系方式：相信你能找到！



