# Payload Support

|Payload|Python|GO|
|:-----|:-----|:---|
|Reflective DLL| x32 / x64 - None| x32 / x64 - In Memory|
|DLL| x32 / x64 - None| x32 / x64 - In Memory|
|EXE| x32 / x64 - On Disk| x32 / x64 - In Memory|
|Shell Code| x32 / x64 - In Memory| x32 / x64 - In Memory|
|Python Code| x32 / x64 - In Memory| x32 / x64 - None|

# Chaining

GO -> GO == NO
PY -> PY == NO
PY -> GO == Yes
